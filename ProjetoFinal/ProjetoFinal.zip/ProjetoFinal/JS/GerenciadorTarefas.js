const $modal = document.getElementById('modal');
const $tituloInput = document.getElementById('idTitulo');
const $descricaoInput = document.getElementById('idDescricao');
const $dataVencimentoInput = document.getElementById('idDataVencimento');
const $prioridadeInput = document.getElementById('idPrioridade');
const $statusInput = document.getElementById('idStatus');
const $colunaInput = document.getElementById('idColuna');
const $idInput = document.getElementById('idInput');


const $ModoCriacaoTarefa = document.getElementById('idModoCriacaoTarefa');
const $ModoEdicaoTarefa = document.getElementById('idModoEdicaoTarefa');

const $ModoCriacaoBtn = document.getElementById('idModoCriacaoBtn');
const $ModoEdicaoBtn = document.getElementById('idModoEdicaoBtn');
const $ExcluirBtn = document.getElementById('idExcluirBtn');

var tarefas = localStorage.getItem("tarefas");
var listaTarefa = tarefas ? JSON.parse(tarefas) : [];

gerarCartao();

//funcao para abrir o modal
function abrirModal() {
    $modal.style.display = "flex";

    $ModoCriacaoTarefa.style.display = "block";
    $ModoCriacaoBtn.style.display = "block";

    $ModoEdicaoTarefa.style.display = "none";
    $ModoEdicaoBtn.style.display = "none";
    $ExcluirBtn.style.display = "none";
}

//função para abrir o modal para editar a tarefa:
function abrirModalParaEditar(id) {
    $modal.style.display = "flex";



    $ModoCriacaoTarefa.style.display = "none";
    $ModoCriacaoBtn.style.display = "none";

    $ModoEdicaoTarefa.style.display = "block";
    $ModoEdicaoBtn.style.display = "block";
    $ExcluirBtn.style.display = "block";

    const index = listaTarefa.findIndex(function (tarefa) {
        return tarefa.id == id;
    });

    const tarefa = listaTarefa[index];

    $idInput.value = tarefa.id;
    $tituloInput.value = tarefa.titulo;
    $descricaoInput.value = tarefa.descricao;
    $dataVencimentoInput.value = tarefa.dataVencimento;
    $prioridadeInput.value = tarefa.prioridade;
    $statusInput.value = tarefa.status;
    $colunaInput.value = tarefa.coluna;

}

//função para fechar o modal:
function fecharModal() {
    $modal.style.display = "none";

    //inicializar novamente o modal:
    $idInput.value = "";
    $tituloInput.value = "";
    $descricaoInput.value = "";
    $dataVencimentoInput.value = "";
    $prioridadeInput.value = "Baixa";
    $statusInput.value = "Pendente";
    $colunaInput.value = "1";
}

//função para resetar as colunas:
function resetarColunas() {
    document.querySelector('[data-coluna="1"] .body').innerHTML = '';
    document.querySelector('[data-coluna="2"] .body').innerHTML = '';
    document.querySelector('[data-coluna="3"] .body').innerHTML = '';
}

//funcao para gerar os cartões de tarefas:
function gerarCartao() {
    resetarColunas();


    listaTarefa.forEach(function (tarefa) {
        const dataFormatada = moment(tarefa.dataVencimento).format('DD/MM/YYYY');


        const colunaBody = document.querySelector(`[data-coluna="${tarefa.coluna}"] .body`)

        /*Linha acrescentadas no cartao:
        draggable="true"
        ondragstart="dragstartHandler(event)"
        id="${tarefa.id}"
        */
        const cartao = `
        <div 
            id="${tarefa.id}"
            class="card" 
            ondblclick="abrirModalParaEditar(${tarefa.id})"
            draggable="true"
            ondragstart="dragstartHandler(event)">                              
            <div class="info">
                <b>Título:</b>
                <span>${tarefa.titulo}</span>
            </div>  

            <div class="info">
                <b>Descrição:</b>
                <span>${tarefa.descricao}</span>
            </div>

            <div class="info">
                <b>Data de Vencimento</b>
                <span>${dataFormatada}</span>
            </div>

            <div class="info">
                <b>Prioridade:</b>
                <span>${tarefa.prioridade}</span>
            </div>
        
            <div class="info">
                <b>Status:</b>
                <span>${tarefa.status}</span>
            </div>
        </div>      
        `;

        colunaBody.innerHTML += cartao;
    });
}


//função para criar as tarefas:
function criarTarefa() {
    const novaTarefa = {
        id: Math.floor(Math.random() * 9999999),
        titulo: $tituloInput.value,
        descricao: $descricaoInput.value,
        dataVencimento: $dataVencimentoInput.value,
        prioridade: $prioridadeInput.value,
        status: $statusInput.value,
        coluna: $colunaInput.value,
    }

    listaTarefa.push(novaTarefa);

    localStorage.setItem("tarefas", JSON.stringify(listaTarefa));

    fecharModal();
    gerarCartao();
}

//função para editar as tarefas:
function editarTarefa() {
    const tarefa = {
        id: $idInput.value,
        titulo: $tituloInput.value,
        descricao: $descricaoInput.value,
        dataVencimento: $dataVencimentoInput.value,
        prioridade: $prioridadeInput.value,
        status: $statusInput.value,
        coluna: $colunaInput.value,
    }

    const index = listaTarefa.findIndex(function (tarefa) {
        return tarefa.id == $idInput.value;
    });

    listaTarefa[index] = tarefa;

    
    localStorage.setItem("tarefas", JSON.stringify(listaTarefa));

    fecharModal();
    gerarCartao();
}

//função para excluir as tarefas:
function excluirTarefa(id) {
    const index = listaTarefa.findIndex(function (tarefa) {
        return tarefa.id == $idInput.value;
    });

    if (index !== -1) {

        listaTarefa.splice(index, 1);

    }

    localStorage.setItem("tarefas", JSON.stringify(listaTarefa));

    fecharModal();
    gerarCartao();
}

//Funções que fazem parte do Drag and Drop
function mudarColuna(tarefa_id, coluna_id) {
    if (tarefa_id && coluna_id) {
        listaTarefa = listaTarefa.map((tarefa) => {
            if (tarefa_id != tarefa.id) return tarefa;

            return {
                ...tarefa,
                coluna: coluna_id,
            };
        });
    }

    localStorage.setItem("tarefas", JSON.stringify(listaTarefa));

    gerarCartao();
}

function dragstartHandler(ev) {
    console.log(ev);
    // Add the target element's id to the data transfer object
    ev.dataTransfer.setData("my_custom_data", ev.target.id);
    ev.dataTransfer.effectAllowed = "move";
}

function dragoverHandler(ev) {
    ev.preventDefault();
    ev.dataTransfer.dropEffect = "move";
}

function dropHandler(ev) {
    ev.preventDefault();
    // Get the id of the target and add the moved element to the target's DOM
    const tarefa_id = ev.dataTransfer.getData("my_custom_data");
    const coluna_id = ev.target.dataset.coluna;

    mudarColuna(tarefa_id, coluna_id);
}
